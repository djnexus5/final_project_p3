package org.example;
public interface Storable {
    void storeGrocery(String name, Grocery grocery);
}
